<div class="openlab-private-comments">
	<label for="ol-private-comment"><?php esc_html_e( 'Make this comment private.', 'openlab-private-comments' ); ?></label> <input type="checkbox" name="ol-private-comment" id="ol-private-comment" value="1" />
</div>
